document.getElementById('textInput').addEventListener('input', function() {

var text = this.value;
var words = text.split(/\s+/).filter(function(n) { return n != '' });

var wordCount = words.length;
document.getElementById('wordCount').textContent = `Words:  ${wordCount}`;

var complicatedWordsCount = words.filter(word => word.length > 10).length;
document.getElementById('complicatedWordsCount').textContent = `Complicated Words (more than 10 characters): ${complicatedWordsCount}`;

var sentences = text.split(/[.!?]+/).filter(function(n) { return n.trim() != '' });

var totalSentences = sentences.length;
document.getElementById('totalSentences').textContent = `Total Sentences: ${totalSentences}`;

var totalCharacters = text.length;
document.getElementById('totalCharacters').textContent = `Total Characters: ${totalCharacters}`;
});